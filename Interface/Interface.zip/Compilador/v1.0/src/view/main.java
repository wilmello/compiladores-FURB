/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;
import model.NumeredBorder;

/**
 *
 * @author Augusto Gern e William Mello
 */
public class main extends javax.swing.JFrame {

    private Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();    
    private JFileChooser fc = null;
    
    /**
     * Cria um novo formulário
     */
    public main() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        paHeader = new javax.swing.JPanel();
        tbNewFile = new javax.swing.JToggleButton();
        tbOpenFile = new javax.swing.JToggleButton();
        tbSave = new javax.swing.JToggleButton();
        tbCopy = new javax.swing.JToggleButton();
        tbPaste = new javax.swing.JToggleButton();
        tbCut = new javax.swing.JToggleButton();
        tbCompile = new javax.swing.JToggleButton();
        tbTeam = new javax.swing.JToggleButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        taEditor = new javax.swing.JTextArea();
        jScrollPane1 = new javax.swing.JScrollPane();
        taMessages = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        taStatusBar = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(900, 600));
        setPreferredSize(new java.awt.Dimension(900, 600));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        paHeader.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        paHeader.setAlignmentX(0.0F);
        paHeader.setAlignmentY(0.0F);

        tbNewFile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/novo.png"))); // NOI18N
        tbNewFile.setText("novo [ctrl+n]");
        tbNewFile.setAlignmentY(0.0F);
        tbNewFile.setHideActionText(true);
        tbNewFile.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        tbNewFile.setPreferredSize(new java.awt.Dimension(109, 59));
        tbNewFile.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        tbNewFile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbNewFileMouseClicked(evt);
            }
        });
        tbNewFile.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tbNewFileKeyPressed(evt);
            }
        });

        tbOpenFile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/abrir.png"))); // NOI18N
        tbOpenFile.setText("abrir [ctrl-o]");
        tbOpenFile.setAlignmentY(0.0F);
        tbOpenFile.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        tbOpenFile.setPreferredSize(new java.awt.Dimension(109, 58));
        tbOpenFile.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        tbOpenFile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbOpenFileMouseClicked(evt);
            }
        });
        tbOpenFile.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tbOpenFileKeyPressed(evt);
            }
        });

        tbSave.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/salvar.png"))); // NOI18N
        tbSave.setText("salvar [ctrl-s]");
        tbSave.setAlignmentY(0.0F);
        tbSave.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tbSave.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        tbSave.setMaximumSize(new java.awt.Dimension(112, 59));
        tbSave.setMinimumSize(new java.awt.Dimension(10, 59));
        tbSave.setPreferredSize(new java.awt.Dimension(109, 59));
        tbSave.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        tbSave.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbSaveMouseClicked(evt);
            }
        });
        tbSave.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tbSaveKeyPressed(evt);
            }
        });

        tbCopy.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/copiar.png"))); // NOI18N
        tbCopy.setText("copiar [ctrl+c]");
        tbCopy.setAlignmentY(0.0F);
        tbCopy.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        tbCopy.setMaximumSize(new java.awt.Dimension(113, 32));
        tbCopy.setMinimumSize(new java.awt.Dimension(113, 32));
        tbCopy.setPreferredSize(new java.awt.Dimension(109, 32));
        tbCopy.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        tbCopy.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbCopyMouseClicked(evt);
            }
        });
        tbCopy.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tbCopyKeyPressed(evt);
            }
        });

        tbPaste.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/colar.png"))); // NOI18N
        tbPaste.setText("colar [ctrl+v]");
        tbPaste.setAlignmentY(0.0F);
        tbPaste.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        tbPaste.setPreferredSize(new java.awt.Dimension(109, 32));
        tbPaste.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        tbPaste.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbPasteMouseClicked(evt);
            }
        });
        tbPaste.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tbPasteKeyPressed(evt);
            }
        });

        tbCut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/recortar.png"))); // NOI18N
        tbCut.setText("recortar [ctrl-x]");
        tbCut.setAlignmentY(0.0F);
        tbCut.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        tbCut.setMargin(new java.awt.Insets(0, 0, 0, 0));
        tbCut.setPreferredSize(new java.awt.Dimension(110, 32));
        tbCut.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        tbCut.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbCutMouseClicked(evt);
            }
        });
        tbCut.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tbCutKeyPressed(evt);
            }
        });

        tbCompile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/compilar.png"))); // NOI18N
        tbCompile.setText("compilar [F9]");
        tbCompile.setAlignmentY(0.0F);
        tbCompile.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        tbCompile.setPreferredSize(new java.awt.Dimension(109, 32));
        tbCompile.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        tbCompile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbCompileMouseClicked(evt);
            }
        });
        tbCompile.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tbCompileKeyPressed(evt);
            }
        });

        tbTeam.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/equipe.png"))); // NOI18N
        tbTeam.setText("equipe [F1]");
        tbTeam.setAlignmentY(0.0F);
        tbTeam.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        tbTeam.setPreferredSize(new java.awt.Dimension(110, 32));
        tbTeam.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        tbTeam.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbTeamMouseClicked(evt);
            }
        });
        tbTeam.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tbTeamKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout paHeaderLayout = new javax.swing.GroupLayout(paHeader);
        paHeader.setLayout(paHeaderLayout);
        paHeaderLayout.setHorizontalGroup(
            paHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paHeaderLayout.createSequentialGroup()
                .addComponent(tbNewFile, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(tbOpenFile, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(tbSave, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(tbCopy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(tbPaste, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(tbCut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(tbCompile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(tbTeam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 34, Short.MAX_VALUE))
        );
        paHeaderLayout.setVerticalGroup(
            paHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tbOpenFile, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(tbSave, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(tbCopy, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(paHeaderLayout.createSequentialGroup()
                .addComponent(tbNewFile, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(tbPaste, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(tbCut, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(tbCompile, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(tbTeam, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        taEditor.setColumns(20);
        taEditor.setRows(5);
        taEditor.setAlignmentX(0.0F);
        taEditor.setAlignmentY(0.0F);
        taEditor.setAutoscrolls(false);
        taEditor.setMinimumSize(new java.awt.Dimension(220, 16));
        taEditor.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                taEditorKeyPressed(evt);
            }
        });
        jScrollPane5.setViewportView(taEditor);
        jScrollPane5 = new JScrollPane(taEditor, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        taEditor.setBorder( new NumeredBorder() );

        taMessages.setEditable(false);
        taMessages.setColumns(20);
        taMessages.setRows(5);
        taMessages.setAlignmentX(0.0F);
        taMessages.setAlignmentY(0.0F);
        taMessages.setAutoscrolls(false);
        taMessages.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                taMessagesKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(taMessages);
        jScrollPane1 = new JScrollPane(taMessages, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

        taStatusBar.setEditable(false);
        taStatusBar.setColumns(20);
        taStatusBar.setForeground(new java.awt.Color(0, 0, 0));
        taStatusBar.setRows(1);
        taStatusBar.setTabSize(0);
        taStatusBar.setAlignmentX(0.0F);
        taStatusBar.setAlignmentY(0.0F);
        taStatusBar.setAutoscrolls(false);
        taStatusBar.setCaretColor(new java.awt.Color(0, 0, 0));
        taStatusBar.setFocusable(false);
        taStatusBar.setSelectedTextColor(new java.awt.Color(0, 0, 0));
        jScrollPane2.setViewportView(taStatusBar);
        jScrollPane2 = new JScrollPane(taStatusBar, ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addComponent(jScrollPane5)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING)
            .addComponent(paHeader, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(paHeader, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
                .addGap(0, 0, 0)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Evento inicial
    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        setLocationRelativeTo( null ); // Coloca o frame no centro da tela
        
        this.setTitle("Compilador 2020/01");
        File dir1 = new File (".");        
        ImageIcon imagemTituloJanela = null; 
        try {
            imagemTituloJanela = new ImageIcon(dir1.getCanonicalPath() +"\\src\\images\\Compilador 32px.png");
        } catch (IOException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.setIconImage(imagemTituloJanela.getImage());
        
        if(fc == null){ // Cria só uma vez para fins de performance
            Boolean old = UIManager.getBoolean("FileChooser.readOnly");
            UIManager.put("FileChooser.readOnly", Boolean.TRUE);        
            
            fc = new JFileChooser(System.getProperty("user.home") + "/Desktop");

            fc.setDialogTitle("Escolha o arquivo de texto:");
            fc.setFileSelectionMode( JFileChooser.FILES_ONLY );        

            fc.removeChoosableFileFilter(fc.getChoosableFileFilters()[0]);
            fc.addChoosableFileFilter(new FileNameExtensionFilter("Arquivos de textos (*.txt)", "txt"));

            UIManager.put("FileChooser.readOnly", old); 
        }        
    }//GEN-LAST:event_formWindowOpened

    // Ao pressionar uma tecla
    private void tbNewFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbNewFileKeyPressed
        try {
            dealsPressedKeys(evt);
        } catch (UnsupportedFlavorException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tbNewFileKeyPressed

    // Ao pressionar uma tecla
    private void taMessagesKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_taMessagesKeyPressed
        try {
            dealsPressedKeys(evt);
        } catch (UnsupportedFlavorException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_taMessagesKeyPressed

    // Ao pressionar uma tecla
    private void taEditorKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_taEditorKeyPressed
        try {
            dealsPressedKeys(evt);
        } catch (UnsupportedFlavorException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_taEditorKeyPressed

    // Ao pressionar uma tecla
    private void tbOpenFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbOpenFileKeyPressed
        try {
            dealsPressedKeys(evt);
        } catch (UnsupportedFlavorException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tbOpenFileKeyPressed

    // Ao pressionar uma tecla
    private void tbSaveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbSaveKeyPressed
        try {
            dealsPressedKeys(evt);
        } catch (UnsupportedFlavorException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tbSaveKeyPressed

    // Ao pressionar uma tecla
    private void tbCopyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbCopyKeyPressed
        try {
            dealsPressedKeys(evt);
        } catch (UnsupportedFlavorException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tbCopyKeyPressed

    // Ao pressionar uma tecla
    private void tbPasteKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbPasteKeyPressed
        try {
            dealsPressedKeys(evt);
        } catch (UnsupportedFlavorException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tbPasteKeyPressed

    // Ao pressionar uma tecla
    private void tbCutKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbCutKeyPressed
        try {
            dealsPressedKeys(evt);
        } catch (UnsupportedFlavorException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tbCutKeyPressed

    // Ao pressionar uma tecla
    private void tbTeamKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbTeamKeyPressed
        try {
            dealsPressedKeys(evt);
        } catch (UnsupportedFlavorException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tbTeamKeyPressed

    // Ao pressionar uma tecla
    private void tbCompileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbCompileKeyPressed
        try {
            dealsPressedKeys(evt);
        } catch (UnsupportedFlavorException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tbCompileKeyPressed

    //Novo arquivo
    private void tbNewFileMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbNewFileMouseClicked
        newFile();
    }//GEN-LAST:event_tbNewFileMouseClicked

    //Abrir arquivo
    private void tbOpenFileMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbOpenFileMouseClicked
        try {
            openFile();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tbOpenFileMouseClicked

    //Salvar arquivo
    private void tbSaveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbSaveMouseClicked
        try {
            saveFile();
        } catch (IOException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tbSaveMouseClicked

    //Copiar
    private void tbCopyMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbCopyMouseClicked
        copy();
    }//GEN-LAST:event_tbCopyMouseClicked

    //Colar    
    private void tbPasteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbPasteMouseClicked
        try {
            paste();
        } catch (UnsupportedFlavorException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tbPasteMouseClicked

    //Recortar
    private void tbCutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbCutMouseClicked
        cut();
    }//GEN-LAST:event_tbCutMouseClicked

    //Compilar
    private void tbCompileMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbCompileMouseClicked
        compile();
    }//GEN-LAST:event_tbCompileMouseClicked

    //Mostrar equipe
    private void tbTeamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbTeamMouseClicked
        showTeam();
    }//GEN-LAST:event_tbTeamMouseClicked
        
    // trata as teclas que foram pressionadas e desvia para os procedimentos corretos
    private void dealsPressedKeys(java.awt.event.KeyEvent evt) throws UnsupportedFlavorException, IOException{
        if((evt.getModifiers() & KeyEvent.CTRL_MASK) != 0){
            switch(evt.getKeyCode()){
                case KeyEvent.VK_N: newFile(); break;  
                case KeyEvent.VK_O: openFile(); break;
                case KeyEvent.VK_S: saveFile(); break;                                                 
            }                            
        }else{
            switch(evt.getKeyCode()){
                case KeyEvent.VK_F9: compile(); break;
                case KeyEvent.VK_F1: showTeam(); break;
            }
        }
    }
    
    //Novo arquivo
    private void newFile(){
        taEditor.setText( "" );
        taMessages.setText( "" );
        taStatusBar.setText( "" );
        taEditor.requestFocus();
        tbNewFile.setSelected(false); // tira o foco do botão apertado
    }
    
    //Abrir arquivo
    private void openFile() throws FileNotFoundException, IOException{               
                        
        int returnVal = fc.showOpenDialog(null);
        
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            if( !fc.getSelectedFile().getName().endsWith(".txt")){
                taMessages.setText( "Tipo de arquivo ("+ fc.getSelectedFile().getName().substring( fc.getSelectedFile().getName().lastIndexOf("."), fc.getSelectedFile().getName().length() ) +") não permitido");
            }else{                                                
                
                try(FileReader fileReader = new FileReader(fc.getSelectedFile());
                    BufferedReader br = new BufferedReader(fileReader)){
                    taEditor.read( br, null);
                }

                taStatusBar.setText( fc.getSelectedFile().getAbsolutePath() );   
            }    
            taMessages.setText("");
        }
        
        taEditor.requestFocus();
        tbOpenFile.setSelected(false); // tira o foco do botão apertado
    }
    
    //Salvar arquivo
    private void saveFile() throws IOException{
     
        
        
        if(taStatusBar.getText().equals("")){
            
            int returnVal = fc.showSaveDialog(null);
            if(returnVal == JFileChooser.APPROVE_OPTION){
                
                if(!fc.getSelectedFile().exists()){
                    fc.getSelectedFile().createNewFile();
                }
                try(FileWriter fw = new FileWriter( fc.getSelectedFile() );
                    BufferedWriter bw = new BufferedWriter( fw )){                
                    taEditor.write( bw );
                    bw.flush();
                }    
                taMessages.setText("");
            }            
            taStatusBar.setText(fc.getSelectedFile().getAbsolutePath());
        }else{
            File file = new File(taStatusBar.getText().trim());
            try(FileWriter fw = new FileWriter( file );
                BufferedWriter bw = new BufferedWriter( fw )){
                taEditor.write( bw );
                bw.flush();
            }            
            taMessages.setText("");
            taStatusBar.setText(fc.getSelectedFile().getAbsolutePath());            
        }        
        taEditor.requestFocus();
        tbSave.setSelected(false); // tira o foco do botão apertado
    }
    
    //Copiar
    private void copy(){
        Transferable transferableText = new StringSelection(taEditor.getSelectedText());
        clipboard.setContents(transferableText, null);        
        taEditor.requestFocus();
        tbCopy.setSelected(false); // tira o foco do botão apertado
    }
    
    //Colar
    private void paste() throws UnsupportedFlavorException, IOException{        
        Transferable t = clipboard.getContents(this);
        if(t != null){            
            if((taEditor.getSelectedText() != null)
            && (!taEditor.getSelectedText().equals(""))){
                taEditor.setText(taEditor.getText().replace(taEditor.getSelectedText(), ""));
            }
            taEditor.insert((String) t.getTransferData(DataFlavor.stringFlavor), taEditor.getCaretPosition());
        }
        taEditor.requestFocus();
        tbPaste.setSelected(false); // tira o foco do botão apertado
    }
    
    //Recortar
    private void cut(){
        copy();
        if(!taEditor.getSelectedText().equals("")){
            taEditor.setText(taEditor.getText().replace(taEditor.getSelectedText(), ""));
        }
        taEditor.requestFocus();
        tbCut.setSelected(false); // tira o foco do botão apertado
    }
    
    //Compilar
    private void compile(){
        taMessages.setText("Compilação de programas ainda não foi implementada");
        tbCut.setSelected(false); // tira o foco do botão apertado
    }
    
    //Mostrar equipe
    private void showTeam(){
        taMessages.setText("Desenvolvido por Augusto Gern e William Mello");
        tbTeam.setSelected(false); // tira o foco do botão apertado
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        /* Cria e exibe o formulário */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                 new main().setVisible(true);                 
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JPanel paHeader;
    private javax.swing.JTextArea taEditor;
    private javax.swing.JTextArea taMessages;
    private javax.swing.JTextArea taStatusBar;
    private javax.swing.JToggleButton tbCompile;
    private javax.swing.JToggleButton tbCopy;
    private javax.swing.JToggleButton tbCut;
    private javax.swing.JToggleButton tbNewFile;
    private javax.swing.JToggleButton tbOpenFile;
    private javax.swing.JToggleButton tbPaste;
    private javax.swing.JToggleButton tbSave;
    private javax.swing.JToggleButton tbTeam;
    // End of variables declaration//GEN-END:variables
}
